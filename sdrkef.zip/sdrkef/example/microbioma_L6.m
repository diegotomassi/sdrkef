% clear workspace and figures
clear all; clc;


%% DATA PROCESSING

% load data
load HMPdataset_100.mat;

% split predictors and class info
X = HMPdataL6;
[Y,label] = grp2idx(HMPbodysubsite);

% Remove predictors with very small values:
null = (sum(X)<0.02);
fprintf('Predictors removed: %d \n ',sum(null))
X(:,null) = [];
[n,p] = size(X);

% Randomly project the data without lossing information: This will help 
% dealing with zeros and general conditioning:
P = randn(p,p); 
Xnew = log(X+0.01)*P;



%% REDUCTIONS VIA RKEF

%Partition: let split the data into 80% for training and 20% for testing
Kfold = 5;
partition = cvpartition(Y,'Kfold',Kfold);
idxtrain = training(partition,1);
idxtest = test(partition,1);

% set dimension of target reduction
r = max(Y);
dim1 = round(r*(r-1)/2);
dim2 = 3;

% set kernel parameter using median heuristic
dists = pdist(Xnew);
sigma = 0.1*(median(dists(:)));


% STEP1: Reduction to dim1:
[redtrain,redtest,~] = RKEF(X(idxtrain,:),Y(idxtrain),dim1,sigma,X(idxtest,:));
     
% STEP2 (optional): Reduction to dim2:
[~,w] = ldr(Y(idxtrain),redtrain,'pfc','disc',dim2);
red_test_final = redtest*w;
red_train_final = redtrain*w;

%% Visualization of the reduction
figure; plotDR(red_train_final, Y(idxtrain),'disc','RKEF'); title('Reduction on training set');
figure; plotDR(red_test_final, Y(idxtest),'disc','RKEF'); title('Reduction on test set');

