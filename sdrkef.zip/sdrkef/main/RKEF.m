function [redtrain,redtest,models] = RKEF(Xtrain,Ytrain,dim,sigma,Xtest,method)
% [redtrain,redtest,models] = RKEF(Xtrain,Ytrain,dim,sigma,Xtest,method)
%
% Dimension reduction via RKEF using SVM with Gaussian kernel.
%   INPUT:
%    (Xtrain,Ytrain): train data, n x 1, n x p
%    dim: dimension to reduce, dim <= r(r-1)/2
%    sigma: bandwidth parameter for Gaussian kernel exp(-|x1-x2|^2/sigma^2)
%    Xtest: test data
%    method: use for reduce from p(p-1)/2 to dim.
%            Options: LAD, AIDA, PFC(default),PCA
%   OUTPUT:
%   redtrain,redtest: reduced data
%   models: pairwise SVM models and coefficients for method.

if nargin < 6
    method = 'PFC';
end
if nargin < 5
    Xtest = Xtrain;
end
if nargin < 4
    sigma = 'auto';
    
end

Ytrain = grp2idx(Ytrain);
r = max(Ytrain);

if dim > r*(r-1)/2
    error('Maximum dimension allowed for reduction: dim=%d', r*(r-1)/2);
end

[ntrain,~] = size(Xtrain);
[ntest,~] = size(Xtest);

redtrain = zeros(ntrain,r*(r-1)/2); 
redtest = zeros(ntest,r*(r-1)/2);
models = cell(1+r*(r-1)/2,1);
aux = 0;
 
for i = 1:r
    for j = i+1:r
        aux = aux+1;
        idxy = find(Ytrain==i|Ytrain==j);
        Ytrainpair = grp2idx(Ytrain(idxy));
        SVMModel = fitcsvm(Xtrain(idxy,:),Ytrainpair,'Standardize',true,'KernelFunction','RBF','KernelScale',sigma);
        [~,score] = predict(SVMModel,Xtrain);
        redtrain(:,aux) = score(:,1);
        [~,score] = predict(SVMModel,Xtest);
        redtest(:,aux) = score(:,1);
        models{aux} = SVMModel;
    end
end

if dim < r*(r-1)/2
    switch method
        case 'LAD'
            [~,w] = ldr(Ytrain,redtrain,'lad','disc',dim);
        case 'AIDA'
            [~,w] = aida(Ytrain,redtrain,dim,'disc');
        case 'PFC'
            [~,w] = ldr(Ytrain,redtrain,'pfc','disc',dim);
        case 'PCA'
            [~,w] = pc(redtrain,dim,'cor');
    end
    redtrain = redtrain*w;
    redtest = redtest*w;
    models{end+1} = w;
else
    models{end+1} = eye(size(redtrain,2));
end
