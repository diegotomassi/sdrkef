function [f,beta,st] = get_penprj(lam)

global lambda;
global n;
global d;
global p;
global M;
global N;  

M0= M;
N0= N;

if lam < 0
    f = inf;
    return
end

lambda = lam;

[A,B] = mysqrt(N);
G = B*M*B;
[x0,aux]=firsteigs(G,d);
[beta,st] = ecis(B*x0);

M = M0;
N = N0;


f = -trace(beta'*M*beta);
%f =  -trace(beta'*M*beta)+ 2*d*(sum(st)-d)/n;
%%%%%% ESTA ES LA QUE USA CHEN
% f = -trace(beta'*M*beta) + d*(sum(st)-d)*log(n)/n;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%f = p*log(trace(Sigma0)-trace(beta'*Sigma0*beta)) + 2*d*sum(st)*2/n;

%RIC
%pe = d*(sum(st)-d);
%f = -(n-pe)*trace(beta'*M*beta) + (n-pe)*log(n/(n-pe)) + pe*(log(n)-1) + 4/(n-pe-2);
