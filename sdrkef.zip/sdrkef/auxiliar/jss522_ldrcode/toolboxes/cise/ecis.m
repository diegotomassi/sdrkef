function [beta,st,k] = ecis(x,XX,YY)

global lambda;
global p;
global n;
global d;
global M;
global N;

if lambda ==0
    beta = x;
    st = ones(p,1);
    return;
end

d = size(x,2);

b0=x;
the = mywt(x); % cambiado de r=.5 a r=1.5
%the = ones(p,1);
dis =1;
st = ones(p,1);
% H0 = diag(the)*diag(1./sqrt(diag(b0*b0')));
H0 = diag(the);

% [A,B] = mysqrt(N);

B = invsqrtm(N);
G = B*M*B;
% G = M;
k=0;

while dis > 1e-6

    k=k+1;
    tp = length(H0);
%     [td,ty] = eig(G-0.5*lambda*B*H0*B);
%     [a1,b1] = sort(diag(ty));
%     if d==2
%     b = B*[td(:,b1(tp)),td(:,b1(tp-1))];
%     elseif d==1
%         b = B*td(:,b1(tp));
%     end
    [b,aux]=firsteigs(G-0.5*lambda*B*H0*B,d);   
    b=B*b;
    dis = subspace(b0,b);
    st0 = st;
    [b,st,ix] = delp(b,st,XX,YY); %esto selecciona y cambia M y N
    if sum(st) < sum(st0)    
        the(ix)=[];
        B = invsqrtm(N);
        G = B*M*B;
%         G = M;
    end;
%     H0 = diag(the)*diag(1./sqrt(diag(b*b')));
    H0 = diag(the);
    b0=b;
       if (size(H0,1)<=2) 
       break;
       end
end

te =0;

for i=1:p
    if st(i)==1
        te = te+1;
    beta(i,1:d) = b(te,1:d);
    elseif st(i)==0
        beta(i,1:d) = zeros(1,d);
    end
end
