function [x,y,ix] = delp(b,st,XX,YY)

global p;
global M;
global N;

t = 0;
s = 0;
y = st;


for i=1:p
   if st(i) == 0  
       continue
   else
       t = t +1;
       if norm(b(t,:)) <= 1e-3
           s = s+1;
           y(i)=0;
           ix(s)=t;
       else
           continue
       end
   end
end

if sum(y) < sum(st)
b(ix,:)=[];

% modificado
[M,N] = MN4aida(YY,XX(:,find(y)));
% modificad
% -------------------
% M(:,ix)=[];
% M(ix,:)=[];
% [A,B] = mysqrt(N);
% Maux = B*M*B;
% N(:,ix)=[];
% N(ix,:)=[];
% [A1,B1] = mysqrt(N);
% Maux(:,ix)=[];
% Maux(ix,:)=[];
% M = A1*Maux*A1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ----ORIGINAL-------------
% N(:,ix)=[];
% N(ix,:)=[];
% M(:,ix)=[];
% M(ix,:)=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%
x = b; 
else
    ix=0;
    x=b;
end
