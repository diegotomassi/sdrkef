################################################################################

LDR: a software package for likelihood based sufficient dimension reduction
        
                by R.D. Cook, L. Forzani and D. Tomassi
                            
                               2009
                
################################################################################

CONTENTS:

 This folder contains a script to reproduce the examples referred to in:
 R.D. Cook, L. Forzani and D. Tomassi: "LDR: a software package for 
 likelihood-based sufficient dimension  reduction". 
 Submitted to the Journal of Statistical Software.
 
 
 

