################################################################################

LDR: a software package for likelihood based sufficient dimension reduction
        
                by R.D. Cook, L. Forzani and D. Tomassi
                            
                               2009
                
################################################################################


This folder contains several data files to use in examples. Please, see DATA.pdf
for further details.

################################################################################
