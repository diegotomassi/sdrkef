%%%This is the script to reproduce figure 2d from the paper by
%%% R. D. Cook and L. Forzani: "Likelihood-based Sufficient Dimension
%%% Reduction". To appear in JASA
%
% BRIEF DESCRIPTION
% The script compares LAD and F2M methods SIR, SAVE and DR by computing the angle 
% between them and the known central subspace. The regression model for the response 
% is Y = X1/4 + a*X1^2/10 + 3*err/5. Figure shows the average angle for different 
% values of parameter 'a' in the regression model. See the paper for details.
% =========================================================================

clear all; 
rng(1);
%setpaths;
nrows = 500;
ncols = 10;
nrep = 50;

% figure 2d
h = 10;
u = 2;
alp = zeros(ncols,2);
alp(1:3,1) = [1 1 1];
alp(1,2)= 1;
alp(ncols-1,2)=1;
alp(ncols,2)=3;
alp = orth(alp);

a = 1;
noise = zeros(nrows,1);
disp(strcat('a =',int2str(a)));

angulosx = 5:5:85;
perturbaciones = perturbBETA(alp,angulosx,nrep);

%%
for j=1:nrep
    j
    % data generation
    X=normrnd(0,1,nrows,ncols);
    yr=sin(X*alp(:,1)) + 1.5*(X*alp(:,2)).^2;
    noise = normrnd(0,1,[length(yr),1]);
    y= yr + a*noise;

    [WX, W]=ldr(y,X,'lad','cont',u,'nslices',h);
    angulos(j,1)=subspace(W,alp)*180/pi;

    [WX, W]=SIR(y,X,'cont',u,'nslices',h);
    angulos(j,2)=subspace(W,alp)*180/pi;
    
    [WX, W]=SAVE(y,X,'cont',u,'nslices',h);
    angulos(j,3)=subspace(W,alp)*180/pi;

    [WX, W]=DR(y,X,'cont',u,'nslices',h);    
    angulos(j,4)=subspace(W,alp)*180/pi;
    
    W = aida(y,X,u,'cont');
    angulos(j,5)=subspace(W,alp)*180/pi;
    
    % DCOV
    [eta,idx] = fedcov(X,y,u,2,'projection');
    angulos(j,6) = subspace(eta,alp)*180/pi;

    parfor k=1:size(perturbaciones,1),
        initval = perturbaciones{k,j};
        
        [~,W] = ldr(y,X,'lad','cont',u,'nslices',h,'initval',initval);
        angulos_pert_lad(j,k) = subspace(W,alp)*180/pi;
        
        eta = fedcov(X,y,u,2,'projection',0.001,initval);
        angulos_pert_SeqFESIC(j,k)=subspace(eta,alp)*180/pi;
    end

end
%%
% resultado usando el valor verdadero como inicio
        initval = alp;
        [~,W] = ldr(y,X,'lad','cont',u,'nslices',h,'initval',initval);
        angulos_ref_lad = subspace(W,alp)*180/pi;
        
        eta = fedcov(X,y,u,2,'projection',0.05,initval);
        angulos_ref_SeqFESIC=subspace(eta,alp)*180/pi;

%%
save('simu_initialization_v2.mat');
disp('=======SIMULATION FINISHED=====');

%% REPORT
angulos_LAD = mean(angulos_pert_lad);
angulos_SeqFESIC = mean(angulos_pert_SeqFESIC);
figure;
plot(angulosx,angulos_LAD,'-o'); hold on;
plot(angulosx,angulos_SeqFESIC,'-d');
plot(angulosx,angulos_ref_lad*ones(size(angulosx)),'--b');
plot(angulosx,angulos_ref_SeqFESIC*ones(size(angulosx)),'--k');