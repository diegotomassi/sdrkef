%%%This is the script to reproduce figure 2d from the paper by
%%% R. D. Cook and L. Forzani: "Likelihood-based Sufficient Dimension
%%% Reduction". To appear in JASA
%
% BRIEF DESCRIPTION
% The script compares LAD and F2M methods SIR, SAVE and DR by computing the angle 
% between them and the known central subspace. The regression model for the response 
% is Y = X1/4 + a*X1^2/10 + 3*err/5. Figure shows the average angle for different 
% values of parameter 'a' in the regression model. See the paper for details.
% =========================================================================

clear all; 
%setpaths;
nrows = 500;
ncols = 10;
nrep = 50;
amax = 15;

% figure 2d
h = 10;
u = 2;
alp = zeros(ncols,2);
alp(1:3,1) = [1 1 1];
alp(1,2)= 1;
alp(ncols-1,2)=1;
alp(ncols,2)=3;
alp = orth(alp);

angulos = zeros(nrep,amax,7);
noise = zeros(nrows,1);
a = 1;
Thrvec = [0.0001 0.0005 0.001 0.005 0.01 0.05 0.1 0.5];
Lambdavec = [1 1.5 2.5 5 7.5 10 15 20 50];
  for i = 1:length(Lambdavec)
      eps = Lambdavec(i);
      disp(strcat('lambda =',num2str(Lambdavec(i))));
      for j=1:nrep
            j
        % data generation
        X=normrnd(0,1,nrows,ncols);
        yr=sin(X*alp(:,1)) + 1.5*(X*alp(:,2)).^2;
        noise1 = chi2rnd(2,[length(yr),1]);
        noise2 = trnd(4,[length(yr),1]);
        pesos = rand(length(yr),1); idx1 = find(pesos<.7); idx2=find(pesos>=.7);
        noise(idx1) = noise1(idx1);
        noise(idx2) = noise2(idx2);
        y= yr + a*noise;

        %% DCOV
        thr = Thrvec(1);
        [eta,idx] = fedcov(X,y,u,eps,'projection',thr);
        angulos(1,i,j) = subspace(eta,alp)*180/pi;
        for k=2:length(Thrvec),
            eta_aux = newThresh(eta,Thrvec(k));
            angulos(k,i,j) = subspace(eta_aux,alp)*180/pi;
        end
      end
end
ang2plot = mean(angulos,3);
[XX,YY] = meshgrid(Thrvec,Lambdavec);
figure; 
surface(XX,YY,ang2plot);