%%%This is the script to reproduce figure 2d from the paper by
%%% R. D. Cook and L. Forzani: "Likelihood-based Sufficient Dimension
%%% Reduction". To appear in JASA
%
% BRIEF DESCRIPTION
% The script compares LAD and F2M methods SIR, SAVE and DR by computing the angle 
% between them and the known central subspace. The regression model for the response 
% is Y = X1/4 + a*X1^2/10 + 3*err/5. Figure shows the average angle for different 
% values of parameter 'a' in the regression model. See the paper for details.
% =========================================================================

clear all; 
%setpaths;
nrows = 500;
ncols = 20;
nrep = 100;
amax = 15;

% figure 2d
h = 10;
u = 2;
alp = zeros(ncols,2);
alp(1:3,1) = [1 1 1];
alp(1,2)= 1;
alp(ncols-1,2)=1;
alp(ncols,2)=3;
 
angulos = zeros(nrep,amax,5);

for a=1:amax
  disp(strcat('a =',int2str(a)));
  for j=1:nrep
    j
    X=normrnd(0,1,nrows,ncols);
 
    yr=.4*a*(X*alp(:,1)).^2 + 3* sin(X*alp(:,2)/4) ;
    y=normrnd(yr,0.2^2);

    [WX, W]=ldr(y,X,'lad','cont',u,'nslices',h);
    angulos(j,a,1)=subspace(W,alp)*180/pi;

    [WX, W]=SIR(y,X,'cont',u,'nslices',h);
    angulos(j,a,2)=subspace(W,alp)*180/pi;
    
    [WX, W]=SAVE(y,X,'cont',u,'nslices',h);
    angulos(j,a,3)=subspace(W,alp)*180/pi;

    [WX, W]=DR(y,X,'cont',u,'nslices',h);    
    angulos(j,a,4)=subspace(W,alp)*180/pi;
    
    [WX, W]=SAVE2(y,X,'cont',u,'nslices',h);
    angulos(j,a,5)=subspace(W,alp)*180/pi;
    
%     nfolds=10;
%     lambdas = .001:.004:1;
%     [f,beta,st]=cise_cv(y,X,u,lambdas,nfolds,'AIDA');
%     angulos(j,a,6)=subspace(beta,alp)*180/pi;
%     cuantos(j,a) = sum(st);

  end
end
%%
meanang = mean(angulos(:,:,[1:4]),1);
%%
figure
plot(squeeze(meanang));
%label
title('Y= 0.4a(\beta_1^{T}X) + 3 sin (\beta_2^{T} X)/4 + 0.2\epsilon');
xlabel('a');
ylabel('ANGLE');
legend('LAD','SIR','SAVE','DR','DCOV','Location','Best');
