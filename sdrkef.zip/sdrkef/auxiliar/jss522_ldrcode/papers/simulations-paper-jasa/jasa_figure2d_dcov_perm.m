%%%This is the script to reproduce figure 2d from the paper by
%%% R. D. Cook and L. Forzani: "Likelihood-based Sufficient Dimension
%%% Reduction". To appear in JASA
%
% BRIEF DESCRIPTION
% The script compares LAD and F2M methods SIR, SAVE and DR by computing the angle 
% between them and the known central subspace. The regression model for the response 
% is Y = X1/4 + a*X1^2/10 + 3*err/5. Figure shows the average angle for different 
% values of parameter 'a' in the regression model. See the paper for details.
% =========================================================================

% clear all; 
%setpaths;
nrows = 300;
ncols = 10;
nrep = 50;
amax = 5;

% figure 2d
h = 10;
u = 2;
alp = zeros(ncols,2);
alp(1:3,1) = [1 1 1];
alp(1,2)= 1;
alp(ncols-1,2)=1;
alp(ncols,2)=3;
alp = orth(alp);

dim = zeros(nrep,amax);
noise = zeros(nrows,1);
for a=1:amax
  disp(strcat('a =',int2str(a)));
  parfor j=1:nrep
    j
    X=normrnd(0,1,nrows,ncols);
 
    yr=sin(X*alp(:,1)) + 1.5*(X*alp(:,2)).^2;
    
%     noise1 = chi2rnd(2,[length(yr),1]);
%    noise2 = trnd(4,[length(yr),1]);
%    pesos = rand(length(yr),1); idx1 = find(pesos<.7); idx2=find(pesos>=.7);
%    noise(idx1) = noise1(idx1);
%    noise(idx2) = noise2(idx2);
    noise = normrnd(0,1,[length(yr),1]);
    y= yr + a*noise;

    dim(j,a) = permSeqFESIC_v2(X,y,'DCOR',999,0.1,alp);
  end
end
%%
disp('DONE.')
 
